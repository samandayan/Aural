package com.auralanalytics.android.challenge

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import androidx.fragment.app.Fragment
import androidx.paging.CombinedLoadStates
import androidx.paging.LoadState
import androidx.paging.LoadStates
import com.auralanalytics.android.challenge.api.RedditService
import com.auralanalytics.android.challenge.models.Listing
import com.auralanalytics.android.challenge.models.ResponseWrapper
import com.auralanalytics.android.challenge.ui.ListViewModel
import org.junit.Test

import org.junit.Assert.*
import org.junit.Before
import org.junit.Rule
import org.junit.runner.RunWith
import org.koin.androidx.viewmodel.ext.android.viewModel
import org.mockito.Mock
import org.mockito.junit.MockitoJUnitRunner

class ExampleUnitTest {
    @Mock
    lateinit var viewModel: ListViewModel

    @get:Rule
    public var instantTaskExecutorRule = InstantTaskExecutorRule()

    @Before
    fun setup() {
        var service = object : RedditService {
            override suspend fun getListing(
                subreddit: String,
                sort: String,
                limit: Int,
                before: String?,
                after: String?
            ): ResponseWrapper<Listing> {
                return ResponseWrapper("", Listing("", "", "", listOf()))
            }
        }

        viewModel = ListViewModel(service, "SOME_STRING")
    }

    @Test
    fun testIsError() {
        var states = CombinedLoadStates(
            LoadState.Error(Throwable()),
            LoadState.Error(Throwable()),
            LoadState.Error(Throwable()),
            LoadStates(
                LoadState.Error(Throwable()),
                LoadState.Error(Throwable()),
                LoadState.Error(Throwable())
            )
        )
        var action = ListViewModel.Action.FromAdapter(states)

        viewModel.send(action)

        assertTrue((viewModel.state.value as ListViewModel.State) is ListViewModel.State.Error)
    }

    @Test
    fun testIsLoading() {
        var states = CombinedLoadStates(
            LoadState.Loading,
            LoadState.Loading,
            LoadState.Loading,
            LoadStates(LoadState.Loading, LoadState.Loading, LoadState.Loading)
        )
        var action = ListViewModel.Action.FromAdapter(states)

        viewModel.send(action)

        assertTrue((viewModel.state.value as ListViewModel.State) is ListViewModel.State.Loading)
    }

    @Test
    fun testIsLoaded() {
        var states = CombinedLoadStates(
            LoadState.NotLoading(true),
            LoadState.NotLoading(true),
            LoadState.NotLoading(true),
            LoadStates(
                LoadState.NotLoading(true),
                LoadState.NotLoading(true),
                LoadState.NotLoading(true)
            )
        )
        var action = ListViewModel.Action.FromAdapter(states)

        viewModel.send(action)

        assertTrue((viewModel.state.value as ListViewModel.State) is ListViewModel.State.Loaded)
    }

}