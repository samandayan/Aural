package com.auralanalytics.android.challenge.ui

import androidx.lifecycle.ViewModel

class PostViewModel : ViewModel() {
}